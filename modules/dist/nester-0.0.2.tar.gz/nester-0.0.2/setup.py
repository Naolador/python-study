from distutils.core import setup

setup(
    name        = 'nester',
    version     = '0.0.2',
    py_modules  = ['nester'],
    author      = 'hfpython',
    author_email = 'hf@123.com',
    description  = 'A simple printer of nester',
    url          = 'http://abc.com',
)
setup(
    name        = 'greetings',
    version     = '0.0.1',
    py_modules  = ['hello'],
    author      = 'stackabuse',
    author_email = 'sa@123.com',
    description  = 'A simple printer of hello',
    url          = 'http://abc.com',
)