""""
This is a nested function module, it can expand all the items from a list,
include a list inside of a list
"""


def print_lol(the_list):
    for each_item in the_list:
        if isinstance(each_item, list):
            print_lol(each_item)
        else:
            print(each_item)
